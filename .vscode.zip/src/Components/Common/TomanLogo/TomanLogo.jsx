import TomanLogoImg from "./../../../Assets/Image/tomanLogo.svg";
const TomanLogo = () => {
  return <img src={TomanLogoImg} className="scale-110" alt="tomanLogo" />;
};

export { TomanLogo };
