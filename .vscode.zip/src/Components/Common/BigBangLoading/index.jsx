import BigBangLoadingGif from "../../../Assets/Gifs/Loading/BigBangLoadingGif.gif";
const BigBangLoading = () => {
  return (
    <figure>
      <img src={BigBangLoadingGif} alt="Loading ... " />
    </figure>
  );
};

export { BigBangLoading };
