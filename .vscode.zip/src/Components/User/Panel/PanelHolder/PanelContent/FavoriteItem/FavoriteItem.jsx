import React from "react";
import { AllTab } from "./AllTab/AllTab";

const FavoriteItem = () => {
  return (
    <>
      <h1 className="p-2">علاقه مندی ها</h1>
      <AllTab />
    </>
  );
};

export { FavoriteItem };
