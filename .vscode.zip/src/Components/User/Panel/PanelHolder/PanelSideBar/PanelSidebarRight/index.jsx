import React from "react";

// Bahr Academy Logo Import
import BahrLogo from "../../../../../../Assets/Images/Logo/BahrLogo.png";

// Components Imports
const PanelSidebarRight = () => {
  return <div className="h-full rounded-full bg-[#ced3fc]"></div>;
};

export { PanelSidebarRight };
