const SingleDataRetuner = (obj, ke) => {
  return obj ? obj.key : "";
};

export { SingleDataRetuner };
