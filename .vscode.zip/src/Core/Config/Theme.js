const Theme = {
  name: "vsd",
  version: "vsdvsd",
};

export default Theme;
